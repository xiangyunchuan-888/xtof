print("inti...!")

__version__ = "1.0.0"
__author__ = "Xiang Yunchuan"

__all__ = ['xlsx_to_fits']

from .converter import xlsx_to_fits
